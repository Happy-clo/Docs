---
title: "LuckPerms Wiki"
---

欢迎来到 LuckPerms wiki。这里你将会找到本插件的完整的使用文档，包括了安装、设置、配置和如何高效的使用 LuckPerms。

### 从何开始?

如果您从未使用过任意权限插件，我推荐你从头开始看。

基础都在[使用教程](/使用.md)页面。完整的命令使用在[命令使用](/命令使用.md)页面。

### 一些有用的链接

- [**开发构建**](https://ci.lucko.me/job/LuckPerms/)
- [**Javadocs**](https://javadoc.io/static/net.luckperms/api/5.4/net/luckperms/api/LuckPerms.html)
