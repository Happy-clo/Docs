---
title: "Receptacle"
description: TrMenu 的菜单底层处理
---

> 模块名称: receptacle

# Receptacle
