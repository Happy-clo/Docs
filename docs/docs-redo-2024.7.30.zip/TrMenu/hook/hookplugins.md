---
title: "支持插件"
---

| 插件          | 用于                 |
| :------------ | :------------------- |
| HeadDatabase  | 物品材质             |
| Oraxen        | 物品材质             |
| PlayerPoints  | 动作 and 变量        |
| SkinsRestorer | 自定义头颅获取       |
| ItemsAdder    | 物品材质             |
| Floodgate     | 脚本 util            |
| Vault         | 动作 and 变量        |
| FastScript    | 自定义脚本(暂不支持) |
| Zaphkiel      | 物品材质             |
