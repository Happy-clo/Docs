---
title: "PAPI 变量"
---

## 菜单总量

> %trmenu_menus%

## 传递参数

> %trmenu_args\_&lt;Index&gt;%

## Metadata 数据

> %trmenu_meta\_&lt;key&gt;
>
> %trmenu_data\_&lt;key&gt;%

## Menu 菜单数据

> %trmenu_menu_page% \# 当前正在查看的页码
>
> %trmenu_menu_pages% \# 菜单总页码量
>
> %trmenu_menu_next% \# 下一页的页码
>
> %trmenu_menu_prev% \# 上一页的页码
>
> %trmenu_menu_title% \# 当前访问的菜单标题

## JavaScript 运算

> %trmenu_js\_&lt;Context&gt;%

:::danger
**警告**: 该变量可能会被恶意利用, 请在确保玩家无法主动访问 PlaceholderAPI 变量的情况使用.

若要启用该功能, 请前往 **settings.yml** 将节点 **Options.Placeholders.JavaScript-Parse** 启用
:::
