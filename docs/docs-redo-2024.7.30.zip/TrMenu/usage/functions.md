---
title: "函数变量"
---
```text
@iconid@
```

# 函数变量

:::tip
函数变量内部 `{}` 若需要使用 `}` 右花括号，请转义使用 `\}` 
:::

## 菜单参数 函数

```text
{<Index>}
```

## Kether 函数

```text
{ke: <Expression>}
```

## JavaScriot 函数

```text
{js: <Expression>}
```

## Meta 变量

```text
{meta: <Key>}
```

## Data 变量

```text
{data: <Key>}
```

## GlobalData 变量

```text
{gdata: <key>}
```

## 内置节点变量

```text
{node: <key>}
```

## 内置脚本函数

```text
${<Key>_<Args0>_<Args1>......}
```

