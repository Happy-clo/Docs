---
title: "Kether"
---

## 学习

[KetherX 中文文档](https://kether.tabooproject.org/)

## 注意

Kether 条件使用在图标、动作中时，因**不包含**任何延时、滞后返回的内容

