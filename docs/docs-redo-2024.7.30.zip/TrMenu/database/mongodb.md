---
title: "MongoDB"
description: MongoDB 数据库
---

## 配置

```yaml
Database:
  Method: MONGODB
  Url:
    Client: "mongodb://localhost:3307"
    Database: trixey
    Collection: menu
```
