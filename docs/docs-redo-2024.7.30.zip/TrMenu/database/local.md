---
title: "LOCAL"
description: 本地数据库
---

## 配置

```yaml
Database:
  Method: LOCAL
```

## 位于

```text
./plugins/TrMenu/data/data.db
```
